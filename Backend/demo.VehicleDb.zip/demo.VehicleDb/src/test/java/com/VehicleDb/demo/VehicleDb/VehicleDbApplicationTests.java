package com.VehicleDb.demo.VehicleDb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
