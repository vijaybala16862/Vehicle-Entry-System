package com.VehicleDb.demo.VehicleDb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehicleDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicleDbApplication.class, args);
		System.out.println("hey fellow code is working");
	}

}
